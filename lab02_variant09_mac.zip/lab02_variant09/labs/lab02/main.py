import argparse
import json
import logging
from datetime import timedelta
from pathlib import Path

from labs.lab02.task1 import Admin, AuditLog, User, UserAccount
from labs.lab02.task2 import audit_headers

DEFAULT_DATA = Path(__file__).parent / "data" / "headers.json"


def run_demo() -> None:
    log = AuditLog()
    user = User("student01", "student01@example.com")
    user.set_password("StrongPass123")
    account = UserAccount(user, log)
    print("Успішний вхід:", account.login("student01", "StrongPass123", "192.0.2.10"))
    print("Авторизований:", account.is_authenticated())
    print("Невдалий вхід:", account.login("student01", "wrong-password", "192.0.2.10"))
    if account.session is not None:
        account.session.last_activity -= timedelta(seconds=901)
    print("Після тайм-ауту:", account.is_authenticated())
    try:
        user.email = "invalid-email"
    except ValueError as error:
        print("Перевірка email:", error)
    user.email = "student_new@example.com"
    print("Новий email:", user.email)
    admin = Admin("admin01", "admin01@example.com", {"read_logs"})
    admin.grant_permission("manage_users")
    print(admin)
    account.logout()
    print("Після виходу:", account.is_authenticated())
    print("Журнал аудиту:")
    log.show_all()


def main() -> None:
    parser = argparse.ArgumentParser(description="Лабораторна №2: консольні утиліти кібербезпеки")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("demo", help="демонстрація ООП")
    analyze = subparsers.add_parser("analyze", help="аудит HTTP-заголовків")
    analyze.add_argument("--headers-file", type=Path, default=DEFAULT_DATA, help="JSON-файл HTTP-заголовків")
    analyze.add_argument("--output-csv", type=Path, default=Path("labs/lab02/data/headers_audit.csv"), help="шлях до CSV-звіту")
    analyze.add_argument("--strict", action="store_true", help="FAIL для ресурсів із відсутніми заголовками")
    analyze.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    args = parser.parse_args()
    if args.command == "demo":
        run_demo()
        return
    logging.basicConfig(level=getattr(logging, args.log_level), format="[%(levelname)s] %(message)s")
    if not args.headers_file.is_file():
        parser.error(f"Файл не знайдено: {args.headers_file}")
    try:
        results = audit_headers(args.headers_file, args.output_csv, args.strict)
    except (OSError, json.JSONDecodeError, ValueError) as error:
        parser.error(str(error))
    print(f"{'Target Resource':43} {'Score':9} {'Grade':6} {'Status':7} Missing Security Headers")
    print("-" * 115)
    for row in results:
        print(f"{row['url']:43} {row['security_score']:>3}/100    {row['grade']:<6} {row['status']:<7} {row['missing_headers']}")
    print(f"\nПеревірено ресурсів: {len(results)}")
    print(f"CSV-звіт: {args.output_csv}")


if __name__ == "__main__":
    main()
