import hashlib
import hmac
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

PASSWORD_ITERATIONS = 200_000
SESSION_TIMEOUT_SEC = 900
EMAIL_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_]{2,63}@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$")


class User:
    def __init__(self, username: str, email: str, role: str = "user", active: bool = True):
        self.username = username
        self._email = ""
        self.email = email
        self.role = role
        self.active = active
        self.__password_hash = b""
        self.__password_salt = b""

    @property
    def email(self) -> str:
        return self._email

    @email.setter
    def email(self, value: str) -> None:
        if not isinstance(value, str) or not EMAIL_PATTERN.fullmatch(value):
            raise ValueError("Некоректний формат email")
        self._email = value

    def set_password(self, password: str) -> None:
        if not isinstance(password, str) or len(password) < 8:
            raise ValueError("Пароль має містити щонайменше 8 символів")
        self.__password_salt = os.urandom(16)
        self.__password_hash = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), self.__password_salt, PASSWORD_ITERATIONS
        )

    def check_password(self, password: str) -> bool:
        if not self.__password_hash or not isinstance(password, str):
            return False
        candidate = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), self.__password_salt, PASSWORD_ITERATIONS
        )
        return hmac.compare_digest(self.__password_hash, candidate)

    def deactivate(self) -> None:
        self.active = False

    def __str__(self) -> str:
        return f"User(username={self.username}, email={self.email}, role={self.role}, active={self.active})"


class Admin(User):
    def __init__(self, username: str, email: str, permissions=None, active: bool = True):
        super().__init__(username, email, role="admin", active=active)
        self.permissions = set(permissions or [])

    def grant_permission(self, permission: str) -> None:
        self.permissions.add(permission)

    def revoke_permission(self, permission: str) -> None:
        self.permissions.discard(permission)

    def has_permission(self, permission: str) -> bool:
        return permission in self.permissions

    def __str__(self) -> str:
        return f"Admin(username={self.username}, email={self.email}, permissions={sorted(self.permissions)})"


class Session:
    def __init__(self, ip: str):
        self.ip = ip
        self.login_time = datetime.now(timezone.utc)
        self.last_activity = self.login_time

    def touch(self) -> None:
        self.last_activity = datetime.now(timezone.utc)

    def is_active(self, timeout_sec: int) -> bool:
        if timeout_sec <= 0:
            raise ValueError("timeout_sec має бути додатним")
        return datetime.now(timezone.utc) - self.last_activity < timedelta(seconds=timeout_sec)


@dataclass
class AuditRecord:
    timestamp: datetime
    username: str
    action: str


class AuditLog:
    def __init__(self):
        self.records: list[AuditRecord] = []

    def add_log(self, username: str, action: str) -> None:
        self.records.append(AuditRecord(datetime.now(timezone.utc), username, action))

    def show_all(self) -> None:
        for record in self.records:
            print(f"{record.timestamp.isoformat()} | {record.username} | {record.action}")


class UserAccount:
    def __init__(self, user: User, audit_log: AuditLog | None = None):
        self.user = user
        self.session: Session | None = None
        self.audit_log = audit_log or AuditLog()

    def login(self, username: str, password: str, ip: str) -> bool:
        if username != self.user.username or not self.user.active or not self.user.check_password(password):
            self.audit_log.add_log(username, "login_failure")
            return False
        self.session = Session(ip)
        self.session.touch()
        self.audit_log.add_log(username, "login_success")
        return True

    def is_authenticated(self) -> bool:
        return self.session is not None and self.session.is_active(SESSION_TIMEOUT_SEC)

    def logout(self) -> None:
        if self.session is not None:
            self.audit_log.add_log(self.user.username, "logout")
            self.session = None

    def __getitem__(self, key: str):
        if key not in {"user", "session", "audit_log"}:
            raise KeyError(key)
        return getattr(self, key)

    def __setitem__(self, key: str, value) -> None:
        allowed = {"user": User, "session": (Session, type(None)), "audit_log": AuditLog}
        if key not in allowed:
            raise KeyError(key)
        if not isinstance(value, allowed[key]):
            raise TypeError(f"Неправильний тип значення для {key}")
        setattr(self, key, value)
