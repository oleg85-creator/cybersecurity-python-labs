# Лабораторна робота №2 — варіант 9

**Варіант:** Аудитор безпеки HTTP-заголовків відповідей.

## Структура
- `main.py` — CLI-команди `demo` та `analyze`.
- `task1.py` — класи User, Admin, Session, AuditLog та UserAccount.
- `task2.py` — аудит HTTP-заголовків, оцінювання ризиків та експорт CSV.
- `data/headers.json` — вхідні тестові дані варіанта 9.

## Запуск на macOS
Виконуйте команди з кореня репозиторію `cybersecurity-python-labs`.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m labs.lab02.main demo
python3 -m labs.lab02.main analyze
```

Якщо віртуальне середовище з лабораторної №1 вже є, повторно створювати його не потрібно — активуйте його та встановіть залежності.

## Параметри analyze
- `--headers-file PATH` — JSON із URL та HTTP-заголовками. Типовий файл: `labs/lab02/data/headers.json`.
- `--output-csv PATH` — шлях до CSV-звіту.
- `--strict` — ресурс із відсутніми заголовками отримує статус FAIL.
- `--log-level DEBUG|INFO|WARNING|ERROR` — рівень логування.

Приклад:
```bash
python3 -m labs.lab02.main analyze --headers-file labs/lab02/data/headers.json --output-csv labs/lab02/data/headers_audit.csv --strict
```

Програма перевіряє чотири заголовки: Strict-Transport-Security, Content-Security-Policy, X-Frame-Options і X-Content-Type-Options. Також шукає версії ПЗ в `Server` та `X-Powered-By`. За кожен відсутній заголовок віднімається 15 балів, за кожен виявлений витік версії — 10 балів. Це навчальна шкала оцінювання, а не офіційний стандарт.

## Перевірка Ruff
```bash
ruff check .
ruff format --check .
```
