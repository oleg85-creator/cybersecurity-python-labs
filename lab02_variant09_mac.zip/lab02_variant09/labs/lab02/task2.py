import csv
import json
import logging
import re
from pathlib import Path

REQUIRED_HEADERS = (
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
)
VERSION_PATTERN = re.compile(r"(?:\b(?:Apache|nginx|PHP|IIS|Express|Tomcat|OpenSSL)[/\s-]*v?\d+(?:\.\d+)+(?:[-+][\w.]+)?)", re.IGNORECASE)


def audit_headers(headers_file: Path, output_csv: Path, strict: bool = False) -> list[dict]:
    """Перевіряє HTTP-заголовки та повертає результати аудиту."""
    with headers_file.open("r", encoding="utf-8") as file:
        resources = json.load(file)
    if not isinstance(resources, list):
        raise ValueError("JSON має містити список ресурсів")

    results = []
    for item in resources:
        if not isinstance(item, dict) or not isinstance(item.get("url"), str) or not isinstance(item.get("headers"), dict):
            logging.warning("Пропущено запис з некоректною структурою")
            continue
        url = item["url"]
        headers = {str(key).lower(): str(value) for key, value in item["headers"].items()}
        missing = [name for name in REQUIRED_HEADERS if name.lower() not in headers]
        leaks = []
        for header_name in ("server", "x-powered-by"):
            value = headers.get(header_name, "")
            if value and VERSION_PATTERN.search(value):
                leaks.append(f"{header_name}: {value}")
        score = max(0, 100 - 15 * len(missing) - 10 * len(leaks))
        if score >= 90:
            grade = "A"
        elif score >= 75:
            grade = "B"
        elif score >= 60:
            grade = "C"
        elif score >= 40:
            grade = "D"
        else:
            grade = "F"
        status = "FAIL" if (strict and missing) or score < 60 else ("WARN" if missing or leaks else "PASS")
        results.append({
            "url": url,
            "security_score": score,
            "grade": grade,
            "status": status,
            "missing_headers": "; ".join(missing) if missing else "None",
            "software_leaks": "; ".join(leaks) if leaks else "None",
        })
        for header in missing:
            logging.warning("%s: missing security header %s", url, header)
        for leak in leaks:
            logging.warning("%s: software version disclosure: %s", url, leak)

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["url", "security_score", "grade", "status", "missing_headers", "software_leaks"]
    with output_csv.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    logging.info("Звіт збережено: %s", output_csv)
    return results
